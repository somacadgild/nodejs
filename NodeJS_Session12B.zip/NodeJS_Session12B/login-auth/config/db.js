//This is all the configuration needed for the database. 
//We are simply setting the url and naming our MongoDB database 
//'expressauth', which will create a new database if it doesn't already exist

module.exports = {  
  url: 'mongodb://localhost/expressauth',
};
